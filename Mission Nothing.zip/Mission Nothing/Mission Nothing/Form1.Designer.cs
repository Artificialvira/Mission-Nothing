﻿namespace Mission_Nothing
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.MoveBgtimer = new System.Windows.Forms.Timer(this.components);
            this.player = new System.Windows.Forms.PictureBox();
            this.leftmovetimer = new System.Windows.Forms.Timer(this.components);
            this.rightmovetimer = new System.Windows.Forms.Timer(this.components);
            this.upmovetimer = new System.Windows.Forms.Timer(this.components);
            this.DownMovetimer = new System.Windows.Forms.Timer(this.components);
            this.MovemunitionTimer = new System.Windows.Forms.Timer(this.components);
            this.moveenetimr = new System.Windows.Forms.Timer(this.components);
            this.enemunitmr = new System.Windows.Forms.Timer(this.components);
            this.eb = new System.Windows.Forms.Button();
            this.rb = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.slab = new System.Windows.Forms.Label();
            this.llab = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.player)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(216, 151);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(218, 85);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // MoveBgtimer
            // 
            this.MoveBgtimer.Enabled = true;
            this.MoveBgtimer.Tick += new System.EventHandler(this.MoveBgtimer_Tick);
            // 
            // player
            // 
            this.player.Image = ((System.Drawing.Image)(resources.GetObject("player.Image")));
            this.player.Location = new System.Drawing.Point(399, 331);
            this.player.Name = "player";
            this.player.Size = new System.Drawing.Size(94, 86);
            this.player.TabIndex = 0;
            this.player.TabStop = false;
            // 
            // leftmovetimer
            // 
            this.leftmovetimer.Enabled = true;
            this.leftmovetimer.Interval = 5;
            this.leftmovetimer.Tick += new System.EventHandler(this.leftmovetimer_Tick);
            // 
            // rightmovetimer
            // 
            this.rightmovetimer.Enabled = true;
            this.rightmovetimer.Interval = 5;
            this.rightmovetimer.Tick += new System.EventHandler(this.rightmovetimer_Tick);
            // 
            // upmovetimer
            // 
            this.upmovetimer.Interval = 5;
            this.upmovetimer.Tick += new System.EventHandler(this.upmovetimer_Tick);
            // 
            // DownMovetimer
            // 
            this.DownMovetimer.Interval = 5;
            this.DownMovetimer.Tick += new System.EventHandler(this.DownMovetimer_Tick);
            // 
            // MovemunitionTimer
            // 
            this.MovemunitionTimer.Enabled = true;
            this.MovemunitionTimer.Interval = 20;
            this.MovemunitionTimer.Tick += new System.EventHandler(this.MovemunitionTimer_Tick);
            // 
            // moveenetimr
            // 
            this.moveenetimr.Enabled = true;
            this.moveenetimr.Tick += new System.EventHandler(this.moveenetimr_Tick);
            // 
            // enemunitmr
            // 
            this.enemunitmr.Enabled = true;
            this.enemunitmr.Interval = 20;
            this.enemunitmr.Tick += new System.EventHandler(this.enemunitmr_Tick);
            // 
            // eb
            // 
            this.eb.BackColor = System.Drawing.Color.Lime;
            this.eb.Location = new System.Drawing.Point(341, 322);
            this.eb.Name = "eb";
            this.eb.Size = new System.Drawing.Size(191, 57);
            this.eb.TabIndex = 1;
            this.eb.Text = "EXIT";
            this.eb.UseVisualStyleBackColor = false;
            this.eb.Visible = false;
            this.eb.Click += new System.EventHandler(this.button2_Click);
            // 
            // rb
            // 
            this.rb.BackColor = System.Drawing.Color.Lime;
            this.rb.Location = new System.Drawing.Point(341, 243);
            this.rb.MaximumSize = new System.Drawing.Size(191, 57);
            this.rb.Name = "rb";
            this.rb.Size = new System.Drawing.Size(191, 57);
            this.rb.TabIndex = 2;
            this.rb.Text = "REPLAY";
            this.rb.UseVisualStyleBackColor = false;
            this.rb.Visible = false;
            this.rb.Click += new System.EventHandler(this.button3_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Stencil", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(87, 103);
            this.label1.MaximumSize = new System.Drawing.Size(1000, 1000);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(700, 82);
            this.label1.TabIndex = 3;
            this.label1.Text = "GAME OVER";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Visible = false;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // slab
            // 
            this.slab.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slab.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.slab.Location = new System.Drawing.Point(643, 9);
            this.slab.MaximumSize = new System.Drawing.Size(191, 57);
            this.slab.Name = "slab";
            this.slab.Size = new System.Drawing.Size(191, 57);
            this.slab.TabIndex = 4;
            this.slab.Text = "SCORE";
            this.slab.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.slab.Click += new System.EventHandler(this.slab_Click);
            // 
            // llab
            // 
            this.llab.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llab.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.llab.Location = new System.Drawing.Point(12, 9);
            this.llab.MaximumSize = new System.Drawing.Size(191, 57);
            this.llab.Name = "llab";
            this.llab.Size = new System.Drawing.Size(191, 57);
            this.llab.TabIndex = 5;
            this.llab.Text = "LEVEL";
            this.llab.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.llab.Click += new System.EventHandler(this.llab_Click);
            // 
            // Form1
            // 
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(846, 429);
            this.Controls.Add(this.llab);
            this.Controls.Add(this.slab);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rb);
            this.Controls.Add(this.eb);
            this.Controls.Add(this.player);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(862, 468);
            this.Name = "Form1";
            this.Text = "Mission Nothing";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.player)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Timer MoveBgtimer;
        private System.Windows.Forms.PictureBox player;
        private System.Windows.Forms.Timer leftmovetimer;
        private System.Windows.Forms.Timer rightmovetimer;
        private System.Windows.Forms.Timer upmovetimer;
        private System.Windows.Forms.Timer DownMovetimer;
        private System.Windows.Forms.Timer MovemunitionTimer;
        private System.Windows.Forms.Timer moveenetimr;
        private System.Windows.Forms.Timer enemunitmr;
        private System.Windows.Forms.Button eb;
        private System.Windows.Forms.Button rb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label slab;
        private System.Windows.Forms.Label llab;
    }
}

