﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WMPLib;

namespace Mission_Nothing


{
    public partial class Form1 : Form
    {
        WindowsMediaPlayer gamemedia;
        WindowsMediaPlayer shootmedia;
        WindowsMediaPlayer explosion;
        PictureBox[] stars;
        int backgrondspeed;
        Random rnd;
        int playerspeed;
        int enespeed;
        int munispeed;

        int score;
        int level;
        int difficulty;
        bool pause;
        bool gameisover;

        PictureBox[] munitions;
        PictureBox[] enemunition;
        PictureBox[] enemies;
        int MunitionSpeed;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            backgrondspeed = 10;
            stars = new PictureBox[10];
            rnd = new Random();
            playerspeed = 6;
            MunitionSpeed = 20;
            enespeed = 4;
            munispeed = 4;
            munitions = new PictureBox[3];

            score = 0;
            level = 1;
            pause = false;
            difficulty = 9;
            gameisover = false;

            Image munition = Image.FromFile(@"asserts\\munition.png");

            Image ene1 = Image.FromFile(@"asserts\\E1.png");
            Image ene2 = Image.FromFile(@"asserts\\E2.png");
            Image ene3 = Image.FromFile(@"asserts\\E3.png");
            Image boss1 = Image.FromFile(@"asserts\\boss1.png");
            Image boss2 = Image.FromFile(@"asserts\\boss2.png");

            enemies = new PictureBox[10];
            for (int i = 0; i < enemies.Length; i++)
            {
                enemies[i] = new PictureBox();
                enemies[i].Size = new Size(60, 60);
                enemies[i].SizeMode = PictureBoxSizeMode.Zoom;
                enemies[i].BorderStyle = BorderStyle.None;
                enemies[i].Visible = false;
                this.Controls.Add(enemies[i]);
                enemies[i].Location = new Point((i + 1) * 70, -70);

            }
            enemies[0].Image = boss1;
            enemies[1].Image = ene1;
            enemies[2].Image = ene2;
            enemies[3].Image = ene3;
            enemies[4].Image = ene1;
            enemies[5].Image = ene2;
            enemies[6].Image = ene3;
            enemies[7].Image = ene2;
            enemies[8].Image = ene3;
            enemies[9].Image = boss2;

            for (int i = 0; i < munitions.Length; i++)
            {
                munitions[i] = new PictureBox();
                munitions[i].Size = new Size(8, 8);
                munitions[i].Image = munition;
                munitions[i].SizeMode = PictureBoxSizeMode.Zoom;
                munitions[i].BorderStyle = BorderStyle.None;
                this.Controls.Add(munitions[i]);
            }
            gamemedia = new WindowsMediaPlayer();
            shootmedia = new WindowsMediaPlayer();
            explosion = new WindowsMediaPlayer();

            gamemedia.URL = "songs\\GameSong.mp3";
            shootmedia.URL = "songs\\shoot.mp3";
            explosion.URL = "songs\\boom.mp3";

            gamemedia.settings.setMode("loop", true);
            gamemedia.settings.volume = 5;
            shootmedia.settings.volume = 1;
            explosion.settings.volume = 6;

            for (int i = 0; i < stars.Length; i++)
            {
                gamemedia.controls.play();
            }

            for (int i = 0; i < stars.Length; i++)
            {
                stars[i] = new PictureBox();
                stars[i].BorderStyle = BorderStyle.None;
                stars[i].Location = new Point(rnd.Next(20, 580), rnd.Next(-10, 400));
                if (i % 2 == 1)
                {
                    stars[i].Size = new Size(2, 2);
                    stars[i].BackColor = Color.White;
                }
                else
                {
                    stars[i].Size = new Size(3, 3);
                    stars[i].BackColor = Color.Silver;
                }
                this.Controls.Add(stars[i]);
            }

            enemunition = new PictureBox[10];
            for (int i = 0; i < enemunition.Length; i++)
            {
                enemunition[i] = new PictureBox();
                enemunition[i].Size = new Size(2, 25);
                enemunition[i].Visible = false;
                enemunition[i].BackColor = Color.Yellow;
                int x = rnd.Next(0, 10);
                enemunition[i].Location = new Point(enemies[x].Location.X, enemies[x].Location.Y - 20);
                this.Controls.Add(enemunition[i]);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void MoveBgtimer_Tick(object sender, EventArgs e)
        {
            for (int i = 0; i < stars.Length / 2; i++)
            {
                stars[i].Top += backgrondspeed;
                if (stars[i].Top >= this.Height)
                {
                    stars[i].Top = -stars[i].Height;
                }
            }
            for (int i = stars.Length/2; i < stars.Length; i++)
            {
                stars[i].Top += backgrondspeed-2;
                if (stars[i].Top >= this.Height)
                {
                    stars[i].Top = -stars[i].Height;
                }
            }

        }

        private void leftmovetimer_Tick(object sender, EventArgs e)
        {
            if (player.Left > 10)
            {
                player.Left -= playerspeed;
            }
        }

        private void rightmovetimer_Tick(object sender, EventArgs e)
        {
            if (player.Right < 800)
            {
                player.Left += playerspeed;
            }
        }

        private void upmovetimer_Tick(object sender, EventArgs e)
        {
            if (player.Top > 10)
            {
                player.Top -= playerspeed;
            }
        }

        private void DownMovetimer_Tick(object sender, EventArgs e)
        {
            if (player.Top < 350)
            {
                player.Top += playerspeed;
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (!pause)
            {
                if (e.KeyCode == Keys.Right)
                {
                    rightmovetimer.Start();
                }
                if (e.KeyCode == Keys.Left)
                {
                    leftmovetimer.Start();
                }
                if (e.KeyCode == Keys.Up)
                {
                    upmovetimer.Start();
                }
                if (e.KeyCode == Keys.Down)
                {
                    DownMovetimer.Start();
                }
            }
        }
        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            rightmovetimer.Stop();
            leftmovetimer.Stop();
            upmovetimer.Stop();
            DownMovetimer.Stop();

            if (e.KeyCode == Keys.Space)
            {
                if (!gameisover)
                {
                    if (pause)
                    {
                        starttimers();
                        label1.Visible = false;
                        gamemedia.controls.play();
                        pause = false;
                    }
                    else
                    {
                        label1.Location = new Point(this.Width / 2 - 120, 150);
                        label1.Text = "PAUSED";
                        label1.Visible = true;
                        gamemedia.controls.pause();
                        StopTimers();
                        pause = true;
                    }
                }
            }
        }

        private void MovemunitionTimer_Tick(object sender, EventArgs e)
        {
            for (int i = 0; i < munitions.Length; i++)
            {
                if (munitions[i].Top > 0)
                {
                    munitions[i].Visible = true;
                    munitions[i].Top -= MunitionSpeed;
                    collision();
                    enecollision();
                }
                else
                {
                    munitions[i].Visible = false;
                    munitions[i].Location = new Point(player.Location.X + 20, player.Location.Y - i * 30);

                }
            }
        }

        private void moveenetimr_Tick(object sender, EventArgs e)
        {
            moveene(enemies, enespeed);
        }

        private void moveene(PictureBox[] array, int speed)
        {
            for (int i = 0; i < array.Length; i++)
            {
                array[i].Visible = true;
                array[i].Top += speed;
                if (array[i].Top > this.Height)
                {
                    array[i].Location = new Point((i + 1) * 70, -70);
                }
            }
        }
        public void collision()
        {
            for (int i=0;i<enemies.Length;i++)
            {
                if ((munitions[0].Bounds.IntersectsWith(enemies[i].Bounds)) || (munitions[1].Bounds.IntersectsWith(enemies[i].Bounds))
                    || (munitions[2].Bounds.IntersectsWith(enemies[i].Bounds)))
                {
                    explosion.controls.play();
                    score += 1;
                    slab.Text = (score < 10) ? "SCORE:0" + score.ToString() : "SCORE:"+score.ToString();

                    if (score % 30 == 0)
                    {
                        level += 1;
                        llab.Text = (level < 10) ? "LEVEL:0" + level.ToString() : "LEVEL:" +

                           level.ToString();
                        if (enespeed <= 10 && munispeed <= 10 && difficulty > 0)
                        {
                            difficulty--;
                            enespeed++;
                            munispeed++;

                        }
                        if (level == 10)
                        {
                            gameover("Nice Done");
                        }
                    }
                    else
                    {
                        llab.Text = "LEVEL:"+level.ToString();
                    }
                    enemies[i].Location = new Point((i+1)*70,-100);

                }
                if (player.Bounds.IntersectsWith(enemies[i].Bounds))
                {
                    explosion.settings.volume =30;
                    explosion.controls.play();
                    player.Visible = false;
                    gameover("");
                }
            }
        }

        public void gameover(string str)
        {
            label1.Text = "GAME OVER";
            label1.Location = new Point(130, 100);
            label1.Visible = true;
            rb.Visible = true;
            eb.Visible = true;
            gamemedia.controls.stop();
            StopTimers();

        }

        public void StopTimers()
        {
            MoveBgtimer.Stop();
            moveenetimr.Stop();
            MovemunitionTimer.Stop();
            enemunitmr.Stop();
            
        }
        public void starttimers()
        {
            moveenetimr.Start();
            MoveBgtimer.Start();
            MovemunitionTimer.Start();
            enemunitmr.Start();
        }

        private void enemunitmr_Tick(object sender, EventArgs e)
        {
            for (int i = 0; i < enemunition.Length - difficulty; i++)
            {
                if (enemunition[i].Top < this.Height)
                {
                    enemunition[i].Visible = true;
                    enemunition[i].Top += munispeed;
                }
                else
                {
                    enemunition[i].Visible = false;
                    int x = rnd.Next(0, 10);
                    enemunition[i].Location = new Point(enemies[x].Location.X + 20, enemies[x].Location.Y + 30);
                }
            }
        }
        public void enecollision()
        {
            for (int i = 0; i < enemunition.Length; i++)
            {
                if (enemunition[i].Bounds.IntersectsWith(player.Bounds))
                {
                    enemunition[i].Visible = false;
                    explosion.controls.play();
                    explosion.settings.volume = 30;
                    player.Visible = false;
                    gameover("");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Environment.Exit(1);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Controls.Clear();
            InitializeComponent();
            Form1_Load(e, e);
        }

        private void slab_Click(object sender, EventArgs e)
        {

        }

        private void llab_Click(object sender, EventArgs e)
        {

        }
        }

        }
    

